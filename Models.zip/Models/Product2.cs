﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tech_Shop.Models
{
    public class Product2
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public string Availability { get; set; }
        public string Brand { get; set; }
        public decimal Price { get; set; }
        public byte[] ImageData { get; set; }
        public int ProductID { get; set; }
        public string ImagePath { get; set; }
        public int ClickCounter { get; set; }
    }

}