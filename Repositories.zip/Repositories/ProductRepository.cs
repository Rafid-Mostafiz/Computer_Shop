﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Tech_Shop.Repositories
{
    public class ProductRepository
    {
    }
}