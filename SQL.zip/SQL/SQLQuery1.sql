﻿UPDATE c_p
SET ImagePath = CONCAT('~/App_Data/DB_IMG/', RIGHT(ImagePath, CHAR_LENGTH(ImagePath) - CHAR_LENGTH('E:\\Xampp\\htdocs\\Techshop_c_p_pic\\')))