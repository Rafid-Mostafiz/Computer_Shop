﻿CREATE TABLE cart (
    cart_id INT PRIMARY KEY IDENTITY(1,1),
    quantity INT NOT NULL,
    c_p_id INT NOT NULL,
    user_id INT NOT NULL,
    FOREIGN KEY (c_p_id) REFERENCES c_p(ID),
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);