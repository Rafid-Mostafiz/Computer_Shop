﻿INSERT INTO [dbo].[c_p] (Name, Availability, Brand, Price, ImageData, product_id, ImagePath, clickcounter)
VALUES
('NVIDIA GeForce GTX 1070 Ti', 'NO', 'Brand B', 25.50, NULL, 102, 'C:\Users\Sanjana\source\repos\Pictures\GeForce-GTX-1070-FE-645x360.jpg', 0);
